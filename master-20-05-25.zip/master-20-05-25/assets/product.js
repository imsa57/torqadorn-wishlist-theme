class Product {
  constructor() {
    (this.acc = []),
      (this.container = document.querySelector(".m-main-product")),
      MinimogTheme.CompareProduct &&
      MinimogTheme.CompareProduct.setCompareButtonsState(),
      MinimogTheme.Wishlist && MinimogTheme.Wishlist.setWishlistButtonsState(),
      this.addRecentViewedProduct(),
      addEventDelegate({
        context: this.container,
        selector:
          (window.__minimog_review_selector || "") +
          ".m-product-collapsible .jdgm-widget-actions-wrapper, .m-product-collapsible .spr-summary-actions-newreview",
        handler: (e) => {
          const t = e.target.closest(".m-product-collapsible").dataset.index;
          setTimeout(() => {
            this.acc[Number(t)].setContentHeight();
          }, 300);
        },
        capture: !0,
      });
  }
  addRecentViewedProduct() {
    const e = getCookie("m-recent-viewed-products");
    let t = e ? JSON.parse(e) : [];
    -1 === t.indexOf(MinimogSettings.productHandle) &&
      (t.unshift(MinimogSettings.productHandle),
        (t = t.slice(0, 20)),
        setCookie("m-recent-viewed-products", JSON.stringify(t)));
  }
}

const lookbookButton = document.getElementById("lookbook-button");
const lookbookTargatedElement = document.querySelector("#product-page-customer-image");
console.log(lookbookTargatedElement);

const lookbookobserver = new MutationObserver((mutations) => {
  mutations.forEach((mutation) => {
    if (mutation.addedNodes.length) {
         lookbookButton.classList.remove("m:hidden");
        
    }
  });
});

lookbookobserver.observe(lookbookTargatedElement, {
  childList: true,
  subtree: true,
});
