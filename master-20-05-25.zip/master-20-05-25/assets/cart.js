class MCartRemoveButton extends HTMLElement {
  constructor() {
    super(),
      this.addEventListener("click", (t) => {
        t.preventDefault();
        (
          this.closest("m-cart") || this.closest("m-cart-drawer-items")
        ).updateQuantity(this.dataset.index, 0);
      });
  }
}
customElements.define("m-cart-remove-button", MCartRemoveButton);
class MCartTemplate extends HTMLElement {
  constructor() {
    super(),
      (this.cartUpdateUnsubscriber = void 0),
      (this.isCartPage = "cart" === MinimogSettings.templateName),
      (this.cartDrawerWrapper = document.querySelector("m-cart-drawer")),
      (this.cartDrawerInner = document.querySelector(".m-cart-drawer__inner")),
      (this.mainCartItems = this.querySelector("[data-minimog-cart-items]")),
      (this.cartSubTotal = this.querySelector("[data-cart-subtotal]")),
      (this.cartDiscount = this.querySelector("[data-minimog-cart-discounts]")),
      (this.giftWrapping = this.querySelector("[data-minimog-gift-wrapping]"));
    let t = this.cartDrawerInner;
    this.isCartPage && (t = document.body),
      (this.loading = new MinimogLibs.AnimateLoading(t, { overlay: t })),
      (this.rootUrl = window.Shopify.routes.root);
    const e = debounce((t) => {
      "id" !== t.target.name && this.onChange(t);
    }, 300);
    this.isCartPage
      ? this.mainCartItems.addEventListener("change", e.bind(this))
      : this.addEventListener("change", e.bind(this)),
      MinimogEvents.subscribe(MinimogTheme.pubSubEvents.cartUpdate, (t) => {
        this.getCart().then((t) => {
          this.updateCartCount(t.item_count);
        });
      });
  }
  updateCartCount(t) {
    document.querySelectorAll(".m-cart-count-bubble").forEach((e) => {
      t > 0
        ? ((e.textContent = t), e.classList.remove("m:hidden"))
        : e.classList.add("m:hidden");
    });
  }
  getCart() {
    return fetchJSON(this.rootUrl + "cart.json");
  }
  connectedCallback() {
    this.cartUpdateUnsubscriber = MinimogEvents.subscribe(
      MinimogTheme.pubSubEvents.cartUpdate,
      (t) => {
        "main-cart-items" !== t.source && this.onCartUpdate();
      }
    );
  }
  disconnectedCallback() {
    this.cartUpdateUnsubscriber && this.cartUpdateUnsubscriber();
  }
  onCartUpdate(t = !0) {
    const { routes: e } = window.MinimogSettings;
    fetch(`${e.cart}?section_id=cart-template`)
      .then((t) => t.text())
      .then((e) => {
        const i = new DOMParser().parseFromString(e, "text/html"),
          n = i.querySelector("[data-minimog-cart-items]"),
          r = i.querySelector("[data-cart-subtotal]"),
          a = i.querySelector("[data-minimog-cart-discounts]"),
          s = i.querySelector("[data-minimog-gift-wrapping]");
        this.isCartPage &&
          ((this.mainCartItems.innerHTML = n.innerHTML),
          t &&
            ((this.cartSubTotal.innerHTML = r.innerHTML),
            (this.cartDiscount.innerHTML = a.innerHTML),
            (this.giftWrapping.innerHTML = s.innerHTML)));
      })
      .catch((t) => {});
  }
  onChange(t) {
    this.updateQuantity(
      t.target.dataset.index,
      t.target.value,
      document.activeElement.getAttribute("name")
    );
  }
  updateQuantity(t, e, i) {
    this.loading.start();
    const { routes: n } = window.MinimogSettings,
      r = JSON.stringify({
        line: t,
        quantity: e,
        sections: this.getSectionsToRender().map((t) => t.section),
        sections_url: window.location.pathname,
      });
    fetch(`${n.cart_change_url}`, { ...fetchConfig(), body: r })
      .then((t) => t.text())
      .then((e) => {
        const i = JSON.parse(e);
        let n = document.getElementById(`MinimogDrawer-quantity-${t}`);
        this.isCartPage &&
          (n = MinimogTheme.config.mqlMobile
            ? document.querySelector(
                `.MinimogQuantity-${t}.MinimogQuantity-mobile`
              )
            : document.querySelector(
                `.MinimogQuantity-${t}.MinimogQuantity-desktop`
              ));
        const r = document.querySelectorAll(".m-cart-item");
        if (i.errors)
          return (
            this.loading.finish(),
            (n.value = n.getAttribute("value")),
            void this.updateLiveRegions(t, i.errors)
          );
        this.classList.toggle("m-cart--empty", 0 === i.item_count),
          this.cartDrawerWrapper &&
            this.cartDrawerWrapper.classList.toggle(
              "m-cart--empty",
              0 === i.item_count
            ),
          this.getSectionsToRender().forEach((t) => {
            (
              document.getElementById(t.id).querySelector(t.selector) ||
              document.getElementById(t.id)
            ).innerHTML = this.getSectionInnerHTML(
              i.sections[t.section],
              t.selector
            );
          });
        const a = i.items[t - 1] ? i.items[t - 1].quantity : void 0;
        let s = "";
        r.length === i.items.length &&
          a !== parseInt(n.value) &&
          (s =
            void 0 === a
              ? window.MinimogStrings.cartError
              : window.MinimogStrings.quantityError.replace(
                  "{{ quantity }}",
                  a
                )),
          this.updateLiveRegions(t, s),
          MinimogEvents.emit(MinimogTheme.pubSubEvents.cartUpdate, {
            ...i,
            source: "main-cart-items",
          });
      })
      .catch(() => {})
      .finally(() => {
        this.loading.finish();
      });
  }
  updateLiveRegions(t, e) {
    let i = document.getElementById(`MinimogCartDrawer-Item-${t}`);
    this.isCartPage && (i = document.getElementById(`MinimogCart-Item-${t}`)),
      "" !== e &&
        i &&
        MinimogTheme.Notification.show({
          target: i,
          type: "warning",
          message: e,
        });
  }
  getSectionInnerHTML(t, e) {
    return new DOMParser().parseFromString(t, "text/html").querySelector(e)
      .innerHTML;
  }
  getSectionsToRender() {
    return [
      {
        id: "MinimogCart",
        section: "cart-template",
        selector: "[data-minimog-cart-items]",
      },
      {
        id: "MinimogCart",
        section: "cart-template",
        selector: "[data-cart-subtotal]",
      },
      {
        id: "MinimogCart",
        section: "cart-template",
        selector: "[data-minimog-cart-discounts]",
      },
      {
        id: "MinimogCart",
        section: "cart-template",
        selector: "[data-minimog-gift-wrapping]",
      },
    ];
  }
}
customElements.define("m-cart", MCartTemplate);
