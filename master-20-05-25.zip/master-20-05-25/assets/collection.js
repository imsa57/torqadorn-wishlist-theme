class Collection {
  constructor() {
    (this.selectors = {
      section: ".facest-filters-section",
      toolbar: ".m-collection-toolbar",
      cols: [".m-toolbar--column-switcher button"],
      productContainer: "[data-product-container]",
      loadMoreBtn: "[data-load-more]",
      sidebar: ".m-sidebar",
      sidebarContent: ".m-sidebar--content",
      openSidebar: ".m-sidebar--open",
      closeSidebar: ".m-sidebar--close",
      filtersWrapper: ".m-filter--wrapper",
      modalButton: "#only-clothes",
    }),
      (this.mobileSortingSelectors = {
        openSorting: ".m-sortby--open",
        closeSorting: ".m-sortby-mobile--close",
        sortingWrapper: ".m-sortby-mobile--wrapper",
        sortingList: ".m-sortby-mobile--content",
      }),
      (this.sectionId = ""),
      (this.isDesignMode = MinimogSettings.design_mode),
      (this.currentPage = 1),
      this.paginationType,
      this.totalPages,
      this.totalProducts,
      this.infiniteLoadingObserver,
      this.showColSwitchers,
      this.cachedCol,
      this.initialCol,
      this.activeCol,
      (this.STORAGE_KEY = "gridColumnViews"),
      (this.MAX_COL_BY_SCREEN_SIZE = { mobile: 2, tablet: 3, desktop: 4 }),
      this.enableFilters,
      this.enableSorting,
      this.filtersType,
      this.filtersPosition,
      this.accordions,
      (this.sideEffectEventsAdded = !1);
  }
  init = () => {
    (this.domNodes = queryDomNodes(this.selectors)),
      (this.mbSortingNodes = queryDomNodes(this.mobileSortingSelectors)),
      this.setData(),
      this.initGridView(),
      this.initFilters(),
      this.initMobileSorting(),
      this.initProducts(),
      (this.domNodes.modalButton.addEventListener('click', this.initModalButton.bind(this))),
      (this.sideEffectEventsAdded = !0),
      MinimogEvents.subscribe("ON_PRODUCT_LIST_UPDATED", () =>
        refreshProductReview()
      ),
      this.handleStickyToolbar(),
      document.addEventListener("matchMobile", () =>
        this.handleStickyToolbar()
      ),
      document.addEventListener("unmatchMobile", () =>
        this.handleStickyToolbar()
      );
      if(document.getElementById('only-clothes')?.classList?.contains('active')){
        this.domNodes.modalButton.classList.remove('active');
        this.initModalButton();
      };
  };
  initModalButton(){
    const allFlexSliderimages = document.querySelectorAll('.all-card-images');
    const allModelCloths = document.querySelectorAll('.only-cloth-image');
    this.domNodes.modalButton.classList.toggle('active');
      allFlexSliderimages.forEach(slider => {
        slider.classList.toggle('m:hidden');
      });
      allModelCloths.forEach(modelCloth => {
        modelCloth.classList.toggle('m:hidden');
      });
  }
  setData = () => {
    const { section: t, productContainer: e } = this.domNodes;
    (this.sectionId = t.dataset.sectionId),
      (this.paginationType = t.dataset.paginationType),
      (this.totalPages = e && Number(e.dataset.totalPages)),
      (this.view = t.dataset.view),
      (this.activeCol = null),
      (this.currentPage = 1),
      (this.initialCol = Number(t.dataset.initialColumn)),
      (this.cachedCol =
        Number(window.localStorage.getItem(this.STORAGE_KEY)) ||
        this.initialCol),
      (this.showColSwitchers = "true" === t.dataset.showColSwitchers),
      (this.enableFilters = "true" === t.dataset.enableFilters),
      (this.enableSorting = "true" === t.dataset.enableSorting),
      (this.filtersType = t.dataset.filtersType),
      (this.filtersPosition = t.dataset.filtersPosition);
  };
  initGridView = () => {
    // console.log(this.isDesignMode, this.cachedCol, this.initialCol);
    this.toggleView(this.isDesignMode ? this.initialCol : this.cachedCol),
      // this.cachedCol && (this.activeCol = this.cachedCol);
      this.updateViewByScreen(),
      addEventDelegate({
        selector: this.selectors.cols[0],
        context: this.domNodes.toolbar,
        handler: (t, e) => this.toggleView(Number(e.dataset.column)),
      }),
      this.initLoadMore();
    this.sideEffectEventsAdded ||
      window.addEventListener("resize", () => {
        const t = this.getDeviceByScreenSize();
        if (this.prevScreen == t) return;
        debounce(this.updateViewByScreen, 500);
      });
  };
  initFilters = () => {
    if (!this.enableFilters) return;
    const { sidebar: t, openSidebar: e, closeSidebar: i } = this.domNodes;
    window.requestAnimationFrame(this.initAccordions),
      e.addEventListener("click", this.openSidebarFilter),
      i.addEventListener("click", this.closeSidebarFilter),
      t.addEventListener(
        "click",
        (e) => e.target === t && this.closeSidebarFilter()
      );
  };
  initMobileSorting = () => {
    if (!this.enableSorting) return;
    const {
      openSorting: t,
      closeSorting: e,
      sortingWrapper: i,
    } = this.mbSortingNodes;
    t.addEventListener("click", this.openMobileSorting),
      e.addEventListener("click", this.closeMobileSorting),
      i.addEventListener(
        "click",
        (t) => t.target === i && this.closeMobileSorting()
      );
  };
  openMobileSorting = () => {
    const { sortingWrapper: t, sortingList: e } = this.mbSortingNodes;
    (t.style.display = "block"),
      window.requestAnimationFrame(() => {
        t.style.setProperty("--m-bg-opacity", "0.5"),
          e.style.setProperty("--m-translate-y", "0");
      });
  };
  closeMobileSorting = (t) => {
    const { sortingWrapper: e, sortingList: i } = this.mbSortingNodes;
    e.style.setProperty("--m-bg-opacity", "0"),
      i.style.setProperty("--m-translate-y", "100%"),
      setTimeout(() => e.style.setProperty("display", "none"), 300);
  };
  initAccordions = () => {
    this.accordions && this.accordions.destroy();
    const { filtersWrapper: t } = this.domNodes;
    t.classList.remove("acc-initialized"),
      (this.accordions = new MinimogLibs.Accordion(t, {
        presetContentHeight:
          window.innerWidth > 1280 && "fixed" !== this.filtersPosition,
        callback: () => t.style.setProperty("opacity", "1"),
      }));
  };
  openSidebarFilter = () => {
    const { sidebar: t, sidebarContent: e, section: i } = this.domNodes;
    (t.style.display = "block"),
      window.requestAnimationFrame(() => {
        t.style.setProperty("--m-bg-opacity", "0.5"),
          e.style.setProperty("--m-translate-x", "0"),
          this.accordions && this.accordions.setContentHeight();
      }),
      i.classList.add("sidebar-open");
  };
  closeSidebarFilter = () => {
    const { sidebar: t, sidebarContent: e, section: i } = this.domNodes;
    i.classList.remove("sidebar-open"),
      (window.innerWidth < 1280 || "fixed" === t.dataset.type) &&
        (e.style.setProperty("--m-translate-x", "-100%"),
        t.style.removeProperty("--m-bg-opacity"),
        setTimeout(() => t.style.removeProperty("display"), 300));
  };
  toggleView = (t) => {
    if (!t || "search" === this.view) return;
    const { cols: e, productContainer: i } = this.domNodes;
    console.log(e[t - 1]);
    if (!i) return;
    const s = i.querySelectorAll("responsive-image");
    s &&
      s.length > 0 &&
      s.forEach((t) => {
        t.disconnectedCallback(), t.connectedCallback();
      });
    const o = this.activeCol || this.initialCol;
    this.showColSwitchers &&
      (e[o - 1].classList.remove("active"), e[t - 1].classList.add("active")),
      i.classList.remove(`m-cols-${o}`),
      i.classList.add(`m-cols-${t}`),
      window.localStorage.setItem(this.STORAGE_KEY, t),
      (this.activeCol = t);
  };
  updateViewByScreen = () => {
    if (1 === this.activeCol) return;
    const t = this.getDeviceByScreenSize(),
      e = this.MAX_COL_BY_SCREEN_SIZE[t];
    this.prevScreen = t;
    this.toggleView(e);
  };
  getDeviceByScreenSize = () =>
    window.innerWidth < 768
      ? "mobile"
      : window.innerWidth < 1024
      ? "tablet"
      : "desktop";
  initLoadMore = () => {
    if (
      "paginate" === this.paginationType ||
      this.totalPages <= 1 ||
      "search" === this.view
    )
      return;
    const { loadMoreBtn: t } = this.domNodes;
    t.addEventListener("click", this.loadMoreProducts),
      "infinite" === this.paginationType &&
        ((this.infiniteLoadingObserver = new IntersectionObserver(
          (t) => {
            t.forEach((t) => {
              1 === t.intersectionRatio && this.loadMoreProducts();
            });
          },
          { threshold: 1 }
        )),
        this.infiniteLoadingObserver.observe(t));
  };
  loadMoreProducts = () => {
    const t = this.currentPage + 1;
    if (t > this.totalPages) return;
    const { productContainer: e, loadMoreBtn: i } = this.domNodes;
    this.toggleLoading(!0),
      fetchSection(this.sectionId, { fromCache: !0, params: { page: t } })
        .then((t) => {
          const r = t;
          if(document.getElementById('only-clothes')?.classList?.contains('active')){
            const allFlexSliderimages = r.querySelectorAll('.all-card-images');
            const allModelCloths = r.querySelectorAll('.only-cloth-image');
            allFlexSliderimages.forEach(slider => {
              slider.classList.add('m:hidden');
            });
            allModelCloths.forEach(modelCloth => {
              modelCloth.classList.remove('m:hidden');
            });
          }
          r
            .querySelectorAll("[data-product-container] .m-product-item")
            .forEach((t) => e.appendChild(t)),
            this.initProducts();
        })
        .catch((t) => {})
        .finally(() => {
          MinimogEvents.emit("ON_PRODUCT_LIST_UPDATED"),
            this.toggleLoading(!1),
            (this.currentPage = t),
            t >= this.totalPages &&
              (i.parentNode.remove(),
              this.infiniteLoadingObserver &&
                this.infiniteLoadingObserver.unobserve(i));
        });
  };
  initProducts = () => {
    MinimogTheme.CompareProduct &&
      MinimogTheme.CompareProduct.setCompareButtonsState(),
      MinimogTheme.Wishlist && MinimogTheme.Wishlist.setWishlistButtonsState();
  };
  toggleLoading = (t) => {
    const { loadMoreBtn: e } = this.domNodes;
    if (e) {
      const i = t ? "add" : "remove";
      e.classList[i]("m-spinner-loading");
    }
  };
  handleStickyToolbar() {
    const t = this.domNodes.toolbar,
      e = t && t.offsetTop;
    let i = 0;
    window.addEventListener("scroll", () => {
      if (MinimogTheme.config.mqlMobile) {
        const s = window.scrollY;
        if (s <= e)
          return void t.classList.remove(
            "scroll-up",
            "m-collection-toolbar--sticky"
          );
        t.classList.add("m-collection-toolbar--sticky"),
          s > t.offsetHeight + e &&
          s > i &&
          !t.classList.contains("scroll-down")
            ? (t.classList.remove("scroll-up"), t.classList.add("scroll-down"))
            : s < i &&
              t.classList.contains("scroll-down") &&
              (t.classList.remove("scroll-down"), t.classList.add("scroll-up")),
          (i = s);
      } else
        t.classList.remove(
          "scroll-up",
          "m-collection-toolbar--sticky",
          "scroll-down"
        );
    });
  }
}
if(!customElements.get('image-scroll-bar')){
  class e extends HTMLElement{
    constructor(){
      super();
      this.progressBar = document.createElement('div');
      this.progressBar.classList.add('scroll-progress-bar');
      this.progressBar.style.width = `${50}%`;
      this.parentElement.appendChild(this.progressBar);
      this.addEventListener('scroll',this.amountScrollDiv.bind(this) );
    }
    amountScrollDiv(){
      const scrollAmount = this.scrollLeft;
      const maxScroll = this.scrollWidth - this.clientWidth;
      const scrollPercent = 50 + (scrollAmount / maxScroll) * 100;
      this.progressBar.style.width = `${scrollPercent}%`;
    }
  }
  customElements.define('image-scroll-bar',e);
}


// document.getElementById('only-clothes').addEventListener('click', function(e) {
//   const allFlexSliderimages = document.querySelectorAll('.all-card-images');
//   const allModelCloths = document.querySelectorAll('.only-cloth-image');
//     this.classList.toggle('active');
//     allFlexSliderimages.forEach(slider => {
//       slider.classList.toggle('m:hidden');
//     });
//     allModelCloths.forEach(modelCloth => {
//       modelCloth.classList.toggle('m:hidden');
//     });
//   });